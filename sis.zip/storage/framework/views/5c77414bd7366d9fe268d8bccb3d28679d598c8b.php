<!doctype html>
<html <?php echo app('translator')->get('en'); ?>>

<head>
    <?php echo $__env->make('partials/_head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('partials/_css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('partials/_script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>
    <?php echo $__env->make('partials/_nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div>
        <?php echo $__env->yieldContent('content'); ?>
    </div>

    <?php echo $__env->make('partials/_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->yieldContent('script'); ?>
</body>

<script>
    $(document).ready(function() {
        const menuItems = document.getElementsByClassName("nav-link");
        const navItems = document.getElementsByClassName("nav-item");

        for (let i = 0; i < menuItems.length; i++) {
            if (menuItems[i].href === location.href) {
                navItems[i].className += " active"
            }
        }
    });
</script>

</html>
<?php /**PATH /home/mbeng/LaravelProjects/MAN2_Akademik/resources/views/main.blade.php ENDPATH**/ ?>