<?php $__env->startSection('content'); ?>
    <div class="container-fluid" style="width: 80%">
        <div class="row justify-content-center" style="margin-top: 50px;">
            <h2>
                Pengelolaan User Sistem
            </h2>
        </div>
        <div align="right">
            <button style="margin-bottom: 10px;" type="button" name="create_record" id="create_record" class="btn btn-success">
                <i class="bi bi-plus-square"></i> Tambah User</button>
        </div>
        <table class="table table-striped table-bordered user_datatable">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nama</th>
                    <th>Email</th>
                    <th>Level</th>
                    <th width="180px">Action</th>
                </tr>
            </thead>
            <tbody></tbody>
        </table>
    </div>
    </div>

    
    <div class="modal fade" id="ajaxModal" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="modal_heading"></h4>
                </div>
                <div class="modal-body">

                    <form action="javascript:void(0)" id="user_form" name="user_form" class="form-horizontal"
                        method="POST">
                        <input type="hidden" name="id_user" id="id_user">
                        <input type="hidden" name="action" id="action" value="Add" />

                        <div class="form-group mb-3">
                            <input type="text" name="name" id="name" class="form-control" placeholder="Name" />
                            <?php if($errors->has('name')): ?>
                                <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
                            <?php endif; ?>
                        </div>
                        <div class="form-group mb-3">
                            <input type="text" name="email" id="email" class="form-control"
                                placeholder="Email Address" />
                            <?php if($errors->has('email')): ?>
                                <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
                            <?php endif; ?>
                        </div>
                        <div class="form-group mb-3">
                            <input type="password" name="password" id="password" class="form-control"
                                placeholder="Password" />
                            <?php if($errors->has('password')): ?>
                                <span class="text-danger"><?php echo e($errors->first('password')); ?></span>
                            <?php endif; ?>
                        </div>
                        <div class="form-group mb-3">
                            <select id="level" name="level" class="form-control">
                                <option value="0">User Reguler</option>
                                <option value="1">User Admin</option>
                            </select>
                        </div>

                        <div class="d-grid mx-auto">
                            <button type="submit" class="btn btn-dark btn-block">Register</button>
                        </div>


                    </form>
                </div>
            </div>
        </div>
    </div>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        const app_path = {
            base_path: "<?php echo e(route('userman.index')); ?>",
        };
    </script>
    <script src="<?php echo e(asset('js/userman.js')); ?>" defer></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mbeng/LaravelProjects/MAN2_Akademik/resources/views/login/userman.blade.php ENDPATH**/ ?>