<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row justify-content-center" style="margin-top: 50px;">
            <h2>
                Hukuman Disiplin Siswa
            </h2>
        </div>

        <div class="row justify-content-center">
            <p>
                Tahun Akademik : <?php echo e($data_th_akademik->tahun); ?> / Semester : <?php echo e($data_th_akademik->semester); ?>

            </p>
        </div>

        <div class="row">
            <div class="col-4">
                <div class="card">
                    <div class="card-header">
                        Eksekusi Hukdis
                    </div>
                    <div class="card-body">

                        <form id="hukdis_form">
                            <div class="form-group row">
                                <label for="inputEmail3" class="col-sm-2 col-form-label">Kelas</label>
                                <div class="col-sm-4">
                                    <select class="form-control" id="select_kelas" name="select_kelas">
                                        <option value="">Semua</option>
                                        <?php $__currentLoopData = $list_kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kelas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($kelas['id_kelas']); ?>"><?php echo e($kelas['nama_kelas']); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="inputnama" class="col-sm-2 col-form-label">Nama Siswa</label>
                                <div class="col-sm-6">
                                    <select class="form-control" id="select_nama" name="select_nama">
                                        <option value="">Pilih Siswa</option>
                                    </select>
                                </div>

                            </div>

                            <div class="form-group row">
                                <label for="inputEmail3" class="col-sm-2 col-form-label">Pelanggaran</label>
                                <div class="col-sm-10">
                                    <select class="form-control" id="select_hukdis" name="select_hukdis">
                                        <option value="">Pilih Pelanggaran</option>
                                        <?php $__currentLoopData = $list_hukdis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hukdis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($hukdis['id_hukdis']); ?>">
                                                <?php echo e($hukdis['deskripsi']); ?> -- Poin : <?php echo e($hukdis['poin']); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>

                            
                            <div class="alert alert-danger print-error-msg" style="display:none;margin-top: 20px;">
                                <ul></ul>
                            </div>

                            <div class="form-group row">
                                <div class="col-sm-10">
                                    <button type="submit" class="btn btn-primary" id="showbtn">Simpan Data</button>
                                </div>
                            </div>
                        </form>
                    </div>

                </div>
            </div>


            <div class="col-8">
                <div class="card">
                    <div class="card-header">
                        Riwayat Hukdis
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">

                            <table class="table table-striped table-bordered" id="tbl_hukdis">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Nama</th>
                                        <th>Kelas</th>
                                        <th>Th. Akademik</th>
                                        <th>Smt.</th>
                                        <th>Tanggal</th>
                                        <th>Pelanggaran</th>
                                        <th>Poin</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>

                                </tbody>
                            </table>

                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        const app_path = {
            base_path: "<?php echo e(route('hukdis.index')); ?>",
        };
    </script>

    <script src="<?php echo e(asset('js/hukdis.js')); ?>" defer></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mbeng/LaravelProjects/MAN2_Akademik/resources/views/hukdis/index.blade.php ENDPATH**/ ?>