<title>SIS-MAN2</title>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<?php /**PATH /home/mbeng/LaravelProjects/MAN2_Akademik/resources/views/partials/_head.blade.php ENDPATH**/ ?>