<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row justify-content-center" style="margin-top: 50px;">
            <h2>
                Rekapitulasi Hukuman Disiplin Siswa
            </h2>
        </div>

        <div class="row">
            <div class="col-sm-4">
                <div class="card">
                    <div class="card-header">
                        Parameter Filter Data
                    </div>
                    <div class="card-body">

                        <form id="hukdis_form">

                            <div class="form-group">
                                <label for="inputEmail3" class="col-sm col-form-label">Tahun</label>
                                <div class="col-sm">
                                    <select class="form-control" id="select_tahun" name="select_tahun">
                                        <option value="">Semua</option>
                                        <?php for($i = 2022; $i < 2030; $i++): ?>
                                            <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                                        <?php endfor; ?>
                                    </select>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="inputEmail3" class="col-sm col-form-label">Semester</label>
                                <div class="col-sm">
                                    <select class="form-control" id="select_semester" name="select_semester">
                                        <option value="">Semua</option>
                                        <option value="1">Ganjil</option>
                                        <option value="2">Genap</option>
                                    </select>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="inputEmail3" class="col-sm col-form-label">Kelas</label>
                                <div class="col-sm">
                                    <select class="form-control" id="select_kelas" name="select_kelas">
                                        <option value="">Semua</option>
                                        <?php $__currentLoopData = $list_kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kelas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($kelas['id_kelas']); ?>"><?php echo e($kelas['nama_kelas']); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="inputnama" class="col-sm col-form-label">Nama Siswa</label>
                                <div class="col-sm">
                                    <input type="text" class="form-control" name="nama" id="nama">
                                </div>
                            </div>

                            
                            <div class="alert alert-danger print-error-msg" style="display:none;margin-top: 20px;">
                                <ul></ul>
                            </div>

                            <div class="form-group">
                                <div class="col-sm">
                                    <button type="submit" class="btn btn-primary" id="showbtn">Tampilkan Data</button>
                                </div>
                            </div>
                        </form>
                    </div>

                </div>
            </div>


            <div class="col-sm-8">
                <div class="card">
                    <div class="card-header">
                        Riwayat Hukdis--
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">

                            <table class="table table-striped table-bordered" id="tbl_hukdis">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Nama</th>
                                        <th>Kelas</th>
                                        <th>Th. Akademik</th>
                                        <th>Smt.</th>
                                        <th>Tanggal</th>
                                        <th>Pelanggaran</th>
                                        <th>Poin</th>
                                    </tr>
                                </thead>
                                <tbody>

                                </tbody>
                            </table>

                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        const app_path = {
            base_path: "<?php echo e(route('hukdisman.index')); ?>",
        };
    </script>

    <script src="<?php echo e(asset('js/hukdisman.js')); ?>" defer></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mbeng/LaravelProjects/MAN2_Akademik/resources/views/hukdis/list_hukdis.blade.php ENDPATH**/ ?>