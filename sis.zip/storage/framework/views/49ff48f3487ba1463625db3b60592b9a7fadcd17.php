<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row justify-content-center" style="margin-top: 50px;">
            <h2>
                Kehadiran Harian Siswa
            </h2>
        </div>
        <div class="row justify-content-center">
            <p>
                Tahun Akademik : <?php echo e($data_th_akademik->tahun); ?> / Semester : <?php echo e($data_th_akademik->semester); ?>

                <input type="text" id="tahun_aktif" value="<?php echo e($data_th_akademik->tahun); ?>" hidden>
                <input type="text" id="semester" value="<?php echo e($data_th_akademik->semester); ?>" hidden>
            </p>
        </div>

        <div class="row justify-content-center">
            <p>
                Tanggal : <?php echo e($tanggal); ?>

            </p>
        </div>
        <div class="row">
            <div class="col">
                Kelas :
                <select id="select_kelas" name="select_kelas" style="margin-bottom: 20px;">
                    <option value="">Pilih Kelas</option>
                    <?php $__currentLoopData = $list_kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kelas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($kelas['id_kelas']); ?>"><?php echo e($kelas['nama_kelas']); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="col">

            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        Siswa - Kelas
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped table-bordered" id="tbl_kehadiran">
                                <thead>
                                    <tr>
                                        <th>No.</th>
                                        <th>Nama</th>
                                        <th>JK</th>
                                        <th>Kelas</th>
                                        <th>Sakit</th>
                                        <th>Izin</th>
                                        <th>Alfa</th>
                                        <th>Ket.</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody></tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        const app_path = {
            base_path: "<?php echo e(route('presensi.index')); ?>",
        };
    </script>

    <script src="<?php echo e(asset('js/attendance.js')); ?>" defer></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mbeng/LaravelProjects/MAN2_Akademik/resources/views/presensi/index.blade.php ENDPATH**/ ?>