@extends('main')

@section('content')
    <div class="container-fluid">
        <div class="row justify-content-center" style="margin-top: 50px;">
            <h2>
                Admin Only !
            </h2>
        </div>
    </div>
@endsection
