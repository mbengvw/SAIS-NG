@extends('main')

@section('content')
    <div class="container-fluid">
        <div class="row justify-content-center" style="margin-top: 50px;">
            <h2>
                Selamat Datang {{ $nama }}
            </h2>
        </div>
    </div>
@endsection

@section('script')
@endsection
